#!/bin/sh

make -f sgx_t_static.mk clean
