# Arduino Basic Hello World

This example simply compiles in wolfSSL and shows the current version number.
